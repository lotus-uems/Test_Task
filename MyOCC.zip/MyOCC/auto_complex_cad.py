from utilities.gratings_scheme import distribute_circles_orthogonal

from OCC.Core import STEPControl
from OCC.Display.WebGl import x3dom_renderer
from OCC.Core.BRep import BRep_Builder
from OCC.Core.TopoDS import TopoDS_Shape, TopoDS_Shell
from OCC.Core.BRepTools import breptools_Read
from OCC.Extend.DataExchange import write_step_file
from OCC.Core.BRepPrimAPI import BRepPrimAPI_MakeTorus, BRepPrimAPI_MakeCylinder
from OCC.Core.TopExp import TopExp_Explorer
from OCC.Core.BRepAlgoAPI import BRepAlgoAPI_Cut
from OCC.Core.gp import gp_Trsf, gp_Vec, gp_Ax1, gp_Pnt, gp_Dir
from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_Transform

from OCC.Core.BRepPrimAPI import BRepPrimAPI_MakeBox

from collections import namedtuple
from math import pi

VectorAngleTuple = namedtuple('VectorAngleTuple', ['vector', 'angle'])


def make_outer_cylinder(diameter_outer: float, height: float):
    outer_cylinder = BRepPrimAPI_MakeCylinder(diameter_outer, height).Shape()
    return outer_cylinder


def make_hole(outer_cylinder_shape, diameter_hole, coords_hole_x_y, height):
    excluded_cylinder = BRepPrimAPI_MakeCylinder(diameter_hole, height).Shape()
    positioned_excluded_cylinder = move_shape(
        excluded_cylinder, (*coords_hole_x_y, 0,))

    outer_cylinder_shape = BRepAlgoAPI_Cut(
        outer_cylinder_shape, positioned_excluded_cylinder
    ).Shape()
    return outer_cylinder_shape


def make_cylinder_with_hole_shape(diameter_outer: float, diameter_hole: float, height: float):
    '''функция в которой создаётся объект прокладка с заданными параметрами'''

    if diameter_hole >= diameter_outer:
        raise ValueError(
            'diameter of the hole should not exceed outer diameter')
    outer_cylinder = BRepPrimAPI_MakeCylinder(diameter_outer, height).Shape()
    excluded_cylinder = BRepPrimAPI_MakeCylinder(diameter_hole, height).Shape()
    cylinder_with_hole = BRepAlgoAPI_Cut(
        outer_cylinder, excluded_cylinder)
    return cylinder_with_hole


def move_shape(shape, coords):
    trsf = gp_Trsf()
    trsf.SetTranslation(gp_Vec(*coords))
    shape = BRepBuilderAPI_Transform(shape, trsf).Shape()
    return shape


def rotate_shape(shape, vector_angle_tuple):
    trsf = gp_Trsf()
    vector = vector_angle_tuple.vector
    angle = vector_angle_tuple.angle
    ax = gp_Ax1(gp_Pnt(0, 0, 0), gp_Dir(gp_Vec(*vector)))
    trsf.SetRotation(ax, angle)
    shape = BRepBuilderAPI_Transform(shape, trsf).Shape()
    return shape


def save_object_as_step_file(shape, filename):
    '''функция в которой происходит запись файла'''
    write_step_file(shape,
                    filename,
                    application_protocol="AP242DIS")


def render_object(shape):
    my_renderer = x3dom_renderer.X3DomRenderer()
    my_renderer.DisplayShape(shape)
    my_renderer.render()


def make_AP242_gratings(diameter_outer: float, diameter_hole: float, distance_between_holes: float,
                        height: float, diameter_hole_displacement_tube: float = 0, coords=(0, 0, 0,),
                        vector_angle_tuple=None, display=True, save_file=True):
    '''функция для динамического создания модели решётки соответствующей STEP AP242 с заданными размерами'''
    filename = f"grating-{diameter_outer}_dh-{diameter_hole}_dd-{diameter_hole_displacement_tube}_h-{height}.stp"
    hole_positions_x_y = distribute_circles_orthogonal(inner_circle_diameter=diameter_hole, outer_circle_diameter=diameter_outer,
                                                       distance_between_circles=distance_between_holes,
                                                       displacement_tube_diameter=diameter_hole_displacement_tube)

    shape_of_gratings = make_outer_cylinder(diameter_outer/2, height)
    for hole_position_x_y in hole_positions_x_y:
        corrected_position_x_y = (
            (hole_position_x_y[0]-diameter_outer/2), (hole_position_x_y[1]-diameter_outer/2))
        print('are we here?')
        shape_of_gratings = make_hole(
            shape_of_gratings, diameter_hole/2, corrected_position_x_y, height)
    if diameter_hole_displacement_tube:
        shape_of_gratings = make_hole(
            shape_of_gratings, diameter_hole_displacement_tube/2, (0, 0,), height)

    shape_of_gratings = move_shape(shape_of_gratings, coords)
    if vector_angle_tuple:
        shape_of_gratings = rotate_shape(shape_of_gratings, vector_angle_tuple)

    if save_file:
        save_object_as_step_file(
            shape_of_gratings, filename)
    if display:
        render_object(shape_of_gratings)
    if save_file:
        return filename


if __name__ == '__main__':
    vector_angle_tuple = VectorAngleTuple(vector=(1, 1, 1), angle=0.25)
    make_AP242_gratings(diameter_outer=100, diameter_hole=15, distance_between_holes=3,
                        height=20, diameter_hole_displacement_tube=20, coords=(2, 2, 2,),
                        vector_angle_tuple=None,)
