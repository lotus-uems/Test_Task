
import OCC
from OCC.Core import STEPControl
from OCC.Display.WebGl import x3dom_renderer
from OCC.Core.BRep import BRep_Builder
from OCC.Core.TopoDS import TopoDS_Shape
from OCC.Core.BRepTools import breptools_Read
from OCC.Extend.DataExchange import write_step_file
from OCC.Core.BRepPrimAPI import BRepPrimAPI_MakeTorus
from OCC.Core.TopExp import TopExp_Explorer

step_reader = STEPControl.STEPControl_Reader()
step_reader.ReadFile('example.stp')
step_reader.TransferRoot()
myshape = step_reader.Shape()
print(dir(myshape))
print(myshape.Composed)
TopExp_Explorer(myshape, 'CIRCLE')

write_step_file(myshape,
                "sample_242.stp",
                application_protocol="AP242DIS")

my_renderer = x3dom_renderer.X3DomRenderer()
my_renderer.DisplayShape(myshape)
my_renderer.render()
