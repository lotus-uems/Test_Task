
def calculate_grid_centered(inner_circle_r, outer_circle_r, bounding_box):

    # совпадает с центром внешнего круга
    initial_pos = (outer_circle_r, outer_circle_r,)

    steps_to_border = int(outer_circle_r // bounding_box)

    starting_x = starting_y = outer_circle_r - steps_to_border * bounding_box
    ending_x = ending_y = outer_circle_r + steps_to_border * bounding_box

    circle_grid = []
    for _step_x in range(steps_to_border*2+1):
        for _step_y in range(steps_to_border*2+1):
            circle_grid.append(
                (starting_x+_step_x * bounding_box, starting_y + _step_y * bounding_box,))
    assert(circle_grid[-1] == (ending_x, ending_y,))

    return circle_grid


def calculate_grid_decentralized(inner_circle_r, outer_circle_r, bounding_box):

    initial_pos = (outer_circle_r+bounding_box/2, outer_circle_r +
                   bounding_box/2,)  # расположено по диагонали от центра

    steps_to_left_border = int(
        (outer_circle_r + bounding_box / 2) // bounding_box)
    steps_to_right_border = int(
        (outer_circle_r - bounding_box / 2) // bounding_box)

    if steps_to_right_border < 0:
        steps_to_right_border = 0

    starting_x = starting_y = outer_circle_r + \
        bounding_box / 2 - steps_to_left_border * bounding_box
    ending_x = ending_y = outer_circle_r + bounding_box / \
        2 + steps_to_right_border * bounding_box

    circle_grid = []
    for _step_x in range(steps_to_left_border+steps_to_right_border+1):
        for _step_y in range(steps_to_left_border+steps_to_right_border+1):
            circle_grid.append(
                (starting_x + _step_x*bounding_box, starting_y + _step_y * bounding_box,))
    assert(circle_grid[-1] == (ending_x, ending_y,))
    return circle_grid


def calculate_grid_median(inner_circle_r, outer_circle_r, bounding_box):

    # расположено посередине справа от центра
    initial_pos = (outer_circle_r + bounding_box/2, outer_circle_r)

    steps_to_left_border = int(
        (outer_circle_r + bounding_box / 2) // bounding_box)
    steps_to_right_border = int(
        (outer_circle_r - bounding_box / 2) // bounding_box)
    if steps_to_right_border < 0:
        steps_to_right_border = 0
    steps_to_upper_border = steps_to_lower_border = int(
        outer_circle_r // bounding_box)

    starting_x = outer_circle_r + bounding_box/2 - steps_to_left_border*bounding_box
    starting_y = outer_circle_r - steps_to_lower_border * bounding_box

    ending_x = outer_circle_r + bounding_box / \
        2 + steps_to_right_border * bounding_box
    ending_y = outer_circle_r + steps_to_upper_border * bounding_box

    circle_grid = []
    for _step_x in range(steps_to_left_border+steps_to_right_border+1):
        for _step_y in range(steps_to_lower_border+steps_to_upper_border+1):
            circle_grid.append(
                (starting_x + _step_x * bounding_box, starting_y + _step_y * bounding_box,))
    assert(circle_grid[-1] == (ending_x, ending_y,))
    return circle_grid


def distribute_circles_orthogonal(inner_circle_diameter, outer_circle_diameter, distance_between_circles=0, displacement_tube_diameter=0):
    """ в этой функции мы определим, как именно хотим распределить трубы теплообменника относительно центра теплообменника
     по сути у нас 3 варианта: centered- когда центр одного из кругов совпадает с центром внешнего круга
    decentralized - как в случае с 4мя кругами вписанными в окружность
    и median - как в случае с 2мя кругами вписанными в окружность"""

    if inner_circle_diameter >= outer_circle_diameter:
        raise ValueError(
            'диаметр трубы теплообменника не может быть равным диаметру внешней трубы. И не может превышать его')
    if displacement_tube_diameter < 0:
        raise ValueError(
            'диаметр трубы вытеснителя не может быть отрицательным')

    inner_circle_r, outer_circle_r = inner_circle_diameter/2, outer_circle_diameter/2

    def filter_grid(grid):
        fitting_circles = []

        # collect circles, which fit into outer circle
        for circle in grid:
            if (circle[0]-outer_circle_r)**2 + (circle[1]-outer_circle_r)**2 <= (outer_circle_r - inner_circle_r)**2:
                fitting_circles.append(circle)

        if displacement_tube_diameter == 0:
            return fitting_circles

        else:
            fitting_circles_reselected = []
            displ_tube_r = displacement_tube_diameter/2
            for circle in fitting_circles:
                if (circle[0]-outer_circle_r)**2 + (circle[1]-outer_circle_r)**2 >= (displ_tube_r + inner_circle_r)**2:
                    fitting_circles_reselected.append(circle)
            return fitting_circles_reselected

    bounding_box = distance_between_circles+inner_circle_r * 2

    circle_centers_positions_centered = calculate_grid_centered(
        inner_circle_r, outer_circle_r, bounding_box)
    circle_centers_positions_decentralized = calculate_grid_decentralized(
        inner_circle_r, outer_circle_r, bounding_box)
    circle_centers_positions_median = calculate_grid_median(
        inner_circle_r, outer_circle_r, bounding_box)

    options = [filter_grid(circle_centers_positions_centered),
               filter_grid(circle_centers_positions_decentralized),
               filter_grid(circle_centers_positions_median)]

    options_by_len = [(len(option), option,) for option in options]
    if max(options_by_len)[0] == 0:
        raise ValueError(
            'с введённым параметрами невозможно расположить трубы в решётке теплообменника')
    return max(options_by_len)[1]


if __name__ == '__main__':
    print(distribute_circles_orthogonal(4, 3))
