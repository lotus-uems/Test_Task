from collections import namedtuple
from numbers import Number
from types import FunctionType

ConverterFunctionsTuple = namedtuple('ConverterTuple',['from_std','to_std'])

CONVERSION_FUNCTIONS_COEFFICIENTS_RU = {
    'линейный размер' : {
        'м' : 1 , 'мм' : 0.001 , 'км' : 1000 , 'см' : 0.01 , 'фут' : 0.3048 , 'дюйм' : 0.0254 ,
        'стандартная морская миля' : 1852 , 'стандартная сухопутная миля' : 1609.344 , 'вершок' : 0.04445 ,
        'аршин' : 0.7112 , 'сажень' : 2.1336 , 'верста' : 1066.8} ,
    'объем' : {
        'м³' : 1 , 'л' : 0.001 , 'чарка' : 1.2299E-4 , 'штоф' : 1.2299E-3 , 'ведро' : 0.012299 ,
        'бочка' : 0.49196 , 'пинта' : 0.56826125E-3 , 'галлон английский' : 4.54609E-3 , 
        'галлон американский' : 3.78541E-3 , 'баррель американский нефтяной' : 0.158988} ,
    'масса' : {
        'кг' : 1 , 'т' : 1000 , 'г' : 0.001 , 'фунт британский (международный)' : 0.45359237 ,
        'унция' : 0.028349523125 , 'золотник' : 0.00426575417 , 'фунт русский' : 0.4095124 , 'пуд' : 16.3804964} ,
    'угол' : {'радиан' : 1 , '°' : 0.017453292, "'" : 2.908882087E-4, '"' : 4.848136811E-6} ,
    'сила' : {'Н': 1 , 'кгс' : 9.80665 , 'тс' : 9806.65 , 'дина' : 0.00001} ,
    'температура' : {
        '°C' : ConverterFunctionsTuple(lambda x:x, lambda x : x) ,
         'К' : ConverterFunctionsTuple(lambda x:x-273.15, lambda x : x+273.15) ,
        '°F' : ConverterFunctionsTuple(lambda x:(x-32)*5/9, lambda x : x*9/5+32)} ,
    'давление' : {'Па' : 1, 'МПа' : 1000000 , 'кПа' : 1000 , 'кгс/см²' : 98066.5 , 'бар' : 100000 , 'м в.ст.' : 9806.65 , 
                  'мм рт.ст.' : 133.322 } ,
    'энергия' : { 'Дж' : 1, 'ГДж' : 1000000000 , 'МДж' : 1000000 , 'кДж' : 1000 , 'Гкал' : 4186800000 , 'ккал' : 4186.8 , 'кВт·ч' : 3600000 } ,
    'мощность' : { 'Вт' : 1 , 'МВт' : 1000000 , 'кВт' : 1000 , 'Гкал/ч' : 1163000 ,  'л.с.' : 735.49875} ,
    'массовый расход' : { 'кг/с' : 1 , 'т/ч' : 0.277778 , 'кг/ч' : 0.000277778 , 'кг/мин' : 0.0166667} ,
    'объемный расход' : { 'м³/с' : 1 , 'м³/ч' : 0.000277778 , 'м³/мин' : 0.0166667 , 'л/мин' : 0.0000166667 , 'л/с' : 0.001} ,
    'теплоемкость' : { 'Дж/(кг·К)' : 1 , 'кДж/(кг·К)' : 1000 , 'ккал/(кг·°С)' : 4186.8 } ,
    'теплопроводность' : {'Вт/(м·К)' : 1 , 'ккал/(ч·м·°С)' : 1.163} ,
    'динамическая вязкость' : {'Па·с' : 1 , 'мПа·с' : 0.001 , 'мкПа·с' : 0.000001 , 'П' : 0.1 , 'cП' : 0.001} ,
    'кинематическая вязкость' : {'м²/с' : 1 , 'мм²/с' : 0.000001 , 'сСт' : 0.000001} ,
    'термическое сопротивление' : {'(м²·К)/Вт' : 1 , '(ч·м²·°С)/ккал' : 0.859845} ,
    'коэффициент теплоотдачи' : {'Вт/(м²·К)' : 1 , 'ккал/(ч·м²·°C)' : 1.163}
    }

def converters_to_functions(converter_from,converter_to):
    '''
    Вспомогательная функция 
    принимает 2 конвертера, возвращающает две функции:
    1. для конверсии из заданной метрики в стандартную метрику
    2. для конверсии из стандартной метрики в требуемую метрику
    '''
    if isinstance(converter_from, Number) and isinstance(converter_to, Number):
        convert_from = lambda x: x*converter_from
        convert_to = lambda x: x/converter_to
        return convert_from, convert_to
    elif isinstance(converter_from, ConverterFunctionsTuple) and isinstance(converter_to,ConverterFunctionsTuple):
        convert_from = converter_from.from_std
        convert_to = converter_to.to_std
        return convert_from, convert_to
    else:
        # исключение будет вызвано, если типы конвертеров не совпадают с ожидаемыми 
        # (ожидается, что оба конвертера - числа, либо оба конвертера - функции)
        raise TypeError('конвертирующие функции и/или коэффициенты найдены, но их применение не предусмотрено')

def get_converter_functions(metric_from,metric_to):
    '''
    Вспомогательная функция
    принимает только названия метрик, возвращает функции для конверсии
    '''
    for category,converters in CONVERSION_FUNCTIONS_COEFFICIENTS_RU.items():
        if metric_from in converters and metric_to in converters:
            converter_from,converter_to = converters[metric_from], converters[metric_to]
            return converters_to_functions(converter_from,converter_to)

    #исключение будет вызвано в случае, если не найдены соответствующие данные:
    raise KeyError('Ошибка при поиске подходящих коэффициентов/функций для конверсии величин')

def convert_metrics(number:float,metric_from:str, metric_to:str)->float:
    """ 
    Принимает 3 аргумента: значение, размерность конвертируемой величины,
    размерность величины в которую конвертируют.
    Возвращает значение конвертированной величины.
    """
    convert_from, convert_to = get_converter_functions(metric_from,metric_to)
    standardized = convert_from(number)
    converted = convert_to(standardized)
    return converted






