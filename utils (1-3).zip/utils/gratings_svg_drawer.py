import cairo
import math
from gratings_scheme import distribute_circles_orthogonal

def make_svg_for_gratings_orthogonal(diameter_heat_exchanger, diameter_outer_tube, distance_between_tubes, displacement_tube_diameter=0):
    tube_centers_coords = distribute_circles_orthogonal(diameter_heat_exchanger,
        diameter_outer_tube,distance_between_tubes,displacement_tube_diameter)
    print(tube_centers_coords)
    with cairo.SVGSurface(
        f"orthogonal-d-he-{diameter_heat_exchanger}-d-out-{diameter_outer_tube}-dist-{distance_between_tubes}-displ-{displacement_tube_diameter}.svg",
        diameter_outer_tube, diameter_outer_tube
    ) as surface:
        cr = cairo.Context(surface)
        cr.move_to(diameter_outer_tube/2,diameter_outer_tube/2)
        #draw outer tube:
        cr.arc(diameter_outer_tube/2,diameter_outer_tube/2, diameter_outer_tube/2, 0, 2*math.pi)
        cr.set_source_rgb(0.6, 0.1, 0.1)
        cr.fill()
        #draw displacement tube:
        if displacement_tube_diameter != 0:
            cr.arc(diameter_outer_tube/2,diameter_outer_tube/2, displacement_tube_diameter/2, 0, 2*math.pi)
            cr.set_source_rgb(0.2, 0.2, 0.4)
            cr.fill()

        for coords_x_y in tube_centers_coords:
            cr.move_to(*coords_x_y)
            cr.arc(*coords_x_y, diameter_heat_exchanger/2, 0, 2*math.pi)
            cr.set_source_rgb(1, 1, 1)
            cr.fill()

if __name__ == '__main__':
    make_svg_for_gratings_orthogonal(34.5,617,14,displacement_tube_diameter = 150)