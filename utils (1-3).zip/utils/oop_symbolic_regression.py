import operator
import math
import random
import sympy

import numpy

from deap import algorithms
from deap import base
from deap import creator
from deap import tools
from deap import gp
from collections import namedtuple
from data_for_symbolic_regression import DATA_GIVEN

import matplotlib.pyplot as plt

FunctionReprTuple = namedtuple('FunctionRepresentationTuple',['function','repr_to_change','repr_replacement','quantity_of_args'])

#Словарь содержит флаги, по которым можно добавлять функции для символической регрессии
#важно: по возможности данные должны быть представлены в формате, подходящем для sympy.simplify
def inverse_val(x):
    return 1/x

DEFAULT_OPERATOR_REPRESENTATION_DICT ={
    'ADD':FunctionReprTuple(operator.add,"add","Add",2),
    'MUL':FunctionReprTuple(operator.mul,"mul","Mul",2),
    'NEG':FunctionReprTuple(operator.neg,"neg","-",1),
    'LOG':FunctionReprTuple(math.log,'math.log',"log",1),
    'EXP':FunctionReprTuple(math.exp,'math.exp',"exp",1),
    'POW':FunctionReprTuple(math.pow,'pow',"Pow",2),
    'INV_VAL':FunctionReprTuple(inverse_val,'inverse_val',"1/",1),
    'SQRT':FunctionReprTuple(math.sqrt,'math.sqrt','Sqrt',1),
}


class NumSRToolboxBuilder:
    '''
    класс инкапсулирующий создание toolbox, 
    при инициализации принимает данные, опционально можно задать список operators,
    по умолчанию это сложение, умножение, отрицательный знак (x заменяется на -x),
     обратное значение (x заменяется на 1/x)
    желательно чтобы они были ключами из DEFAULT_OPERATOR_REPRESENTATION_DICT
    если же предоставляемые функции недостаоточны, нужно создавать свой словарь по аналогии
    и передавать при инициализации и передавать в кварг operator_representation_dict
    также можно задать константы. По умолчанию значения от -10 до 10 с шагом 0.1, одна константа
    '''
    def __init__(self, operators = ["ADD","MUL","NEG","INV_VAL"],
        operator_representation_dict = DEFAULT_OPERATOR_REPRESENTATION_DICT,
        ephemeral_constants = [("rand101", lambda: random.randint(-10,10)/10)]):

        self._ephemeral_constants = ephemeral_constants
        self.__operator_representation_dict = operator_representation_dict
        self.__make_pset(operators)       


    def __make_pset(self,operators):
        self._pset = gp.PrimitiveSet("MAIN", 1)
        try:
            for operator in operators:
                self._pset.addPrimitive(self.__operator_representation_dict[operator].function,
                                        self.__operator_representation_dict[operator].quantity_of_args )
        except KeyError:
            raise KeyError('all operators should be in operator_representation_dict.keys()')

        for ephemeral_constant in self._ephemeral_constants:
            self._pset.addEphemeralConstant(*ephemeral_constant)

        self._pset.renameArguments(ARG0='x')

    def build_toolbox(self):
        creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
        creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMin)
        toolbox = base.Toolbox()
        toolbox.register("expr", gp.genHalfAndHalf, pset=self._pset, min_=1, max_=2)
        toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr)
        toolbox.register("population", tools.initRepeat, list, toolbox.individual)
        toolbox.register("compile", gp.compile, pset=self._pset)
        toolbox.register("get_pset",lambda:self._pset)
        
        return toolbox

    def makefunc_adapt_repr(self):
        def adapt_representation_of_operators_for_sympy(formula_str):
            for func_repr_tuple in self.__operator_representation_dict.values():
                formula_str = formula_str.replace(
                    func_repr_tuple.repr_to_change,
                    func_repr_tuple.repr_replacement
                )
            return formula_str
        return adapt_representation_of_operators_for_sympy


class ParametrizedSRStarter:
    def __init__(self,toolbox, data=None, evaluating_func=None, eval_type='mean squared',branching_complexity = 5):
        if data == None:
            raise ValueError('data field is necessary!')
        self.toolbox = toolbox
        self.data=data
        self._eval_func=evaluating_func
        self._eval_type = eval_type
        self.branching_complexity = branching_complexity
        if not self._eval_func:
            self._eval_func = self.make_evaluating_func()


    def make_evaluating_func(self):
        if self._eval_type == 'manhattan distance':
            def eval_func(individual,points):
                func = toolbox.compile(expr=individual)
                manhattan_distance = 0
                for [x,y] in points:
                    try:
                        manhattan_distance += abs(func(x) - y) 
                    except ValueError:
                        manhattan_distance += abs(x)+abs(y)
                    except ZeroDivisionError:
                        manhattan_distance += abs(x)+abs(y)
                return manhattan_distance/len(points),
        elif self._eval_type == 'mean squared':
            def eval_func(individual,points):
                func = self.toolbox.compile(expr=individual)
                mean_squared = 0
                for [x,y] in points:
                    try:
                        mean_squared += (func(x) - y)**2
                    except ValueError:
                        mean_squared += x**2+y**2
                    except ZeroDivisionError:
                        mean_squared += x**2+y**2
                    except OverflowError:
                        mean_squared += 10*(x**2+y**2)
                return math.sqrt(mean_squared)/len(points),
        else:
            raise ValueError('данный вид рассчёта отклонения не поддерживается')
        return eval_func
    
    def make_regression(self, mu=20, lambda_=250,cxpb=0.5, mutpb=0.3, ngen=1000, verbose=True, hof_size = 30,n_population=200):
        self.toolbox.register("evaluate", self._eval_func, points=self.data)
        self.toolbox.register("select", tools.selTournament, tournsize=3)
        self.toolbox.register("mate", gp.cxOnePoint)
        self.toolbox.register("expr_mut", gp.genFull, min_=0, max_=2)
        self.toolbox.register("mutate", gp.mutUniform, expr=self.toolbox.expr_mut, pset=self.toolbox.get_pset())
        self.toolbox.decorate("mate", gp.staticLimit(key=operator.attrgetter("height"), max_value=self.branching_complexity))
        self.toolbox.decorate("mutate", gp.staticLimit(key=operator.attrgetter("height"), max_value=self.branching_complexity))
        self._pop = self.toolbox.population(n=n_population)
        self.hof = tools.HallOfFame(hof_size)
    
        stats_fit = tools.Statistics(lambda ind: ind.fitness.values)
        stats_size = tools.Statistics(len)
        mstats = tools.MultiStatistics(fitness=stats_fit, size=stats_size)
        mstats.register("avg", numpy.mean)
        mstats.register("std", numpy.std)
        mstats.register("min", numpy.min)
        mstats.register("max", numpy.max)

        self._pop, self.log = algorithms.eaMuPlusLambda(self._pop, self.toolbox, mu=mu, lambda_=lambda_,cxpb=cxpb, mutpb=mutpb, ngen=ngen, stats=mstats,
                                    halloffame=self.hof, verbose=verbose)

        return self.hof

class PlotMaker:
    def __init__(self,best_funcs_reprs,data):
        self.best_funcs_reprs = best_funcs_reprs
        self.data = data
        self.range_arg = self.get_range_of_x()
        self.legends = []

    def get_range_of_x(self):
        _value_min = min(point[0] for point in self.data)
        _value_max = max(point[0] for point in self.data)
        value_delta = _value_max - _value_min

        value_min = _value_min-0.5*value_delta
        value_max = _value_max+0.5*value_delta
        value_step = (value_max-value_min)/20
        values = []
        value_current= value_min
        for _ in range(20):
            values.append(value_current)
            value_current += value_step
        return values

    def make_plot(self, filename):
        self._plot_data()
        self._plot_funcs()
        plt.plot(legend=self.legends)
        plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
        plt.savefig(filename)
    
    def _plot_data(self):
        X = []
        Y = []
        for data_point in self.data:
            X.append(data_point[0])
            Y.append(data_point[1])
        plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
        plt.plot(X, Y, "o")
        self.legends.append('data')


    def _plot_funcs(self):

        for func_repr_tuple in self.best_funcs_reprs:
            X = []
            Y = []
            for arg_point in self.range_arg:
                try:
                    X.append(arg_point)
                    Y.append(func_repr_tuple[0](arg_point))
                except ValueError or ZeroDivisionError or OverflowError:
                    pass
            plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
            plt.plot(X,Y)
            self.legends.append(str(func_repr_tuple[1]))
                


if __name__ == '__main__':
    #создаём toolbox с заданными операторами, константами (по желанию можем поменять ряд настроек по умолчанию)
    toolbox_creator = NumSRToolboxBuilder(operators = ["ADD","NEG","INV_VAL"],
       ephemeral_constants = [("rand101", lambda: random.randint(-1000,1000)/10), ("rand102", lambda: random.randint(-1000,1000)/10)])
    model_toolbox = toolbox_creator.build_toolbox()
    #создаём функцию для адаптации формул для последующей обработки при помощи sympy (в человекочитаемый формат)
    adapt_repr_func = toolbox_creator.makefunc_adapt_repr()
    #определяем параметры регресии и начинаем
    regressor = ParametrizedSRStarter(model_toolbox,DATA_GIVEN,branching_complexity=12)
    best_models = regressor.make_regression(ngen=10000)
    best_func_repr_tuples = []
    #используем функцию, адаптирующую формулы для того, чтобы получить человекочитаемое представление формул
    for model in best_models:
        adapted_model_repr = adapt_repr_func(str(model))
        simplified_repr = sympy.simplify(adapted_model_repr)
        best_func_repr_tuples.append((model_toolbox.compile(model),simplified_repr,))
        print(simplified_repr)
    new_filename = 'complexity-12-ani-2extralargeconstants-10000gens'

    with open(new_filename+'.txt', 'w') as f:
        for func_repr_tuple in best_func_repr_tuples:
            f.write(str(func_repr_tuple[1]))
            f.write('\n')

    # создаём экземпляр класса который строит графики, выводим в файл полученный график (!!!!!!!НАДО ЗАДАВАТЬ НАЗВАНИЕ ФАЙЛА!!!!!)
    plot_maker = PlotMaker(best_func_repr_tuples,DATA_GIVEN)
    plot_maker.make_plot(filename=new_filename+'.png')
    

