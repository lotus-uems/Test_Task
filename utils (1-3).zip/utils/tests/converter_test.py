from ..converter import converters_to_functions, get_converter_functions, convert_metrics
from unittest import TestCase 


class TestConvertMetrics(TestCase):
    def test_valid_conversion_C_to_K(self):
        temperature_kelvin = convert_metrics(100, '°C', 'К')
        self.assertEqual(temperature_kelvin, 373.15)
    def test_valid_conversion_K_to_C(self):
        temperature_celsius = convert_metrics(0,'К', '°C' )
        self.assertEqual(temperature_celsius, -273.15)
    def test_valid_conversion_K_to_F(self):
        temperature_fahrenheit = convert_metrics(393.15, 'К', '°F')
        self.assertEqual(248, temperature_fahrenheit)
    def test_valid_pointless_conversion_K_to_K(self):
        temperature_kelvin = convert_metrics(400, 'К', 'К')
        self.assertEqual(400, temperature_kelvin)
    def test_valid_conversion_pound_to_ounces(self):
        mass_ounces = convert_metrics(200,'фунт британский (международный)','унция')
        self.assertEqual(3200, mass_ounces)
    def test_test_minutes_to_seconds_conversion(self):
        angle_seconds = convert_metrics(0.1,"'", '"')
        self.assertAlmostEqual(6, angle_seconds) 
    def test_invalid_cross_category_conversion_fails(self):
        with self.assertRaises(KeyError):
            convert_metrics(200,'К','унция')
    def test_invalid_not_implemented_conversion_fails(self):
        with self.assertRaises(KeyError):
            convert_metrics(200,'световой год','километр')

class TestConvertersToFunctions(TestCase):
    def test_unsupported_str_types_fails(self):
        with self.assertRaises(TypeError):
            converters_to_functions('К','унция')
    def test_unsupported_num_func_types_fails(self):
        with self.assertRaises(TypeError):
            converters_to_functions(3,lambda x: 10)
    def test_funcs_from_coefficients(self):
        converter_from, converter_to = converters_to_functions(3,5)
        self.assertEqual(converter_from(103),(lambda x:x*3)(103))
        self.assertEqual(converter_to(103),(lambda x:x/5)(103))


class TestGetConverterFunctions(TestCase):
    def test_nonexistent_converter_search_fails(self):
        with self.assertRaises(KeyError):
            get_converter_functions('Сименс','Микросименс')
    def test_cross_category_converter_search_fails(self):
        with self.assertRaises(KeyError):
            get_converter_functions('К','унция')




        